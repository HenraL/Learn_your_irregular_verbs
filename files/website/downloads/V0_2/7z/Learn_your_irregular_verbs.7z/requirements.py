class root:
    def __init__(self):
        self.a="requirements"
    def start(self):
        print(f"self.a={self.a}")