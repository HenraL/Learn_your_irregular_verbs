Author: Yann Thorimbert - 2017
Title: The Phantom Racer - V. PyWeek23

To play, just run main.py

This is a racing game written in python + pygame.
Dependencies:
	-pygame
	-thorpy(distributed along with the game)


!!! Tested only with Python3.x !!! It should work with Python2...


Background image 1 from Paula Riva (opengameart).
Background image 2 from http://pixelatedthings.tumblr.com/post/72196742661


Note: an updated version will be released, this is like a beta version.

